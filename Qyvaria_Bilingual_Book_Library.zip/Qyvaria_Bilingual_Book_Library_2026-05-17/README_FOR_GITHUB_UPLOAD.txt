QYVARIA BILINGUAL BOOK LIBRARY - 17 MAY 2026

This ZIP contains a multi-volume English/Czech publication pack for the Qyvaria Kernel and the conceptual Qyvaria OS relationship.

Main PDF series:
00 Publication Pack Index
01 Grand Technical Compendium
02 Architecture Atlas
03 Agent and Cognition Encyclopedia
04 Developer and Release Manual
05 Audit and Evidence Dossier
06 Qyvaria OS Integration Blueprint
07 Open Intelligence Manifesto
08 Embedded Module Atlas

The pack is designed for GitHub upload. A practical repository placement is:
docs/books/

The software licensing decision stated by the author:
- Qyvaria Kernel software: Apache License 2.0
- Qyvaria OS software: Apache License 2.0

The PDFs are explanatory documentation prepared from the supplied source corpus and the earlier technical study.
The OS integration volume is explicitly conceptual and should not be read as a claim of already-verified implementation.

Generated on: 2026-05-17
